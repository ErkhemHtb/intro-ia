package games.otherGame;

import iialib.games.model.IRole;

public enum otherGameRole implements IRole{ 
		HORIZONTAL, 	// For the player playing its tiles hally
		VERTICAL		// For the player playing its tiles vertically
}
