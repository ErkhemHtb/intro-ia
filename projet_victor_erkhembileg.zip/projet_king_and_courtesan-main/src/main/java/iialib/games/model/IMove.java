package iialib.games.model;

/**
 * used to characterize game moves
 * It has to be implemented by some class in a real game
 */
public interface IMove {
	
	
	
}
